package com.sharad.recepemgmt.bean;

import java.util.List;

/**
 * This is  the Request body bean used to map request data
 * @author SHARAD
 *
 */

public class RecepesMgmtRequestBean {
	
	private int recepieId;
	private String recepieName;
	private String recepieCreationDate;
	private String recepieUpdateDate;
	private String isVegeterian;
	private String survingPeople;
	private List<Ingredients> recIngredients;
	private String cookingIntructions;
	public int getRecepieId() {
		return recepieId;
	}
	public void setRecepieId(int recepieId) {
		this.recepieId = recepieId;
	}
	public String getRecepieName() {
		return recepieName;
	}
	public void setRecepieName(String recepieName) {
		this.recepieName = recepieName;
	}
	public String getRecepieCreationDate() {
		return recepieCreationDate;
	}
	public void setRecepieCreationDate(String recepieCreationDate) {
		this.recepieCreationDate = recepieCreationDate;
	}
	public String getRecepieUpdateDate() {
		return recepieUpdateDate;
	}
	public void setRecepieUpdateDate(String recepieUpdateDate) {
		this.recepieUpdateDate = recepieUpdateDate;
	}
	public String getIsVegeterian() {
		return isVegeterian;
	}
	public void setIsVegeterian(String isVegeterian) {
		this.isVegeterian = isVegeterian;
	}
	public String getSurvingPeople() {
		return survingPeople;
	}
	public void setSurvingPeople(String survingPeople) {
		this.survingPeople = survingPeople;
	}
	public List<Ingredients> getRecIngredients() {
		return recIngredients;
	}
	public void setRecIngredients(List<Ingredients> recIngredients) {
		this.recIngredients = recIngredients;
	}
	public String getCookingIntructions() {
		return cookingIntructions;
	}
	public void setCookingIntructions(String cookingIntructions) {
		this.cookingIntructions = cookingIntructions;
	}
	public RecepesMgmtRequestBean() {
		super();
	}
	public RecepesMgmtRequestBean(int recepieId, String recepieName, String recepieCreationDate,
			String recepieUpdateDate, String isVegeterian, String survingPeople, List<Ingredients> recIngredients,
			String cookingIntructions) {
		super();
		this.recepieId = recepieId;
		this.recepieName = recepieName;
		this.recepieCreationDate = recepieCreationDate;
		this.recepieUpdateDate = recepieUpdateDate;
		this.isVegeterian = isVegeterian;
		this.survingPeople = survingPeople;
		this.recIngredients = recIngredients;
		this.cookingIntructions = cookingIntructions;
	}
	
	

}
