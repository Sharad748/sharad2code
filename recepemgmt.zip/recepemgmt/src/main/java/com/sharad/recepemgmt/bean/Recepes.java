package com.sharad.recepemgmt.bean;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * This is Bean/Entity used for table RECEPE_DETAILS
 * @author SHARAD
 *
 */

@Entity
@Table(name="RECEPE_DETAILS")
public class Recepes {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="RECEPE_ID")
	private int recepieId;
	
	
	@Column(name="RECEPE_NAME")
	private String recepieName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SYS_CREATION_DATE")
	@JsonFormat(pattern="dd‐MM‐yyyy HH:mm", timezone = "UTC")
	private Date recepieCreationDate;
	
	
	@Column(name="IS_VEGETERIAN")
	private String isVegeterian;
	
	@Column(name="NO_OF_SERVING")
	private String survingPeople;
	

	@OneToMany(mappedBy = "recepes", cascade = {CascadeType.ALL})
	@JsonManagedReference
	private List<Ingredients> recIngredients;
	
	@Column(name="COOKING_INSTRUCTIONS")
	private String cookingIntructions;

	
	public List<Ingredients> getRecIngredients() {
		return recIngredients;
	}

	public void setRecIngredients(List<Ingredients> recIngredients) {
		this.recIngredients = recIngredients;
	}

	public int getRecepieId() {
		return recepieId;
	}

	public void setRecepieId(int recepieId) {
		this.recepieId = recepieId;
	}

	public Date getRecepieCreationDate() {
		return recepieCreationDate;
	}

	public void setRecepieCreationDate(Date recepieCreationDate) {
		 if(null!=recepieCreationDate) {
			 System.out.println("Date Validator");
			  Calendar c = Calendar.getInstance();
		        c.setTime(recepieCreationDate);
		        c.add(Calendar.HOUR_OF_DAY, 5);
		        c.add(Calendar.MINUTE, 30);
		        this.recepieCreationDate= c.getTime(); 
		 }else {
			 this.recepieCreationDate = recepieCreationDate;
		 }
	}

	public String getIsVegeterian() {
		return isVegeterian;
	}

	public void setIsVegeterian(String isVegeterian) {
		this.isVegeterian = isVegeterian;
	}

	public String getSurvingPeople() {
		return survingPeople;
	}


	public void setSurvingPeople(String survingPeople) {
		this.survingPeople = survingPeople;
	}

	public String getCookingIntructions() {
		return cookingIntructions;
	}

	public void setCookingIntructions(String cookingIntructions) {
		this.cookingIntructions = cookingIntructions;
	}
		

	public String getRecepieName() {
		return recepieName;
	}

	public void setRecepieName(String recepieName) {
		this.recepieName = recepieName;
	}

	public Recepes() {
	}
	
	

	public Recepes(String recepieName, Date recepieCreationDate, String recepieUpdateDate, String isVegeterian,
			String survingPeople, List<Ingredients> recIngredients, String cookingIntructions) {
		super();
		this.recepieName = recepieName;
		this.recepieCreationDate = recepieCreationDate;
		this.isVegeterian = isVegeterian;
		this.survingPeople = survingPeople;
		this.recIngredients = recIngredients;
		this.cookingIntructions = cookingIntructions;
	}

	@Override
	public String toString() {
		return "Recepes [recepieId=" + recepieId + ", recepieName=" + recepieName + ", recepieCreationDate="
				+ recepieCreationDate + ", isVegeterian=" + isVegeterian
				+ ", survingPeople=" + survingPeople + ", recIngredients=" + recIngredients + ", cookingIntructions="
				+ cookingIntructions + "]";
	}

}
