package com.sharad.recepemgmt.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sharad.recepemgmt.bean.Recepes;
import com.sharad.recepemgmt.dao.RecepeRepository;
import com.sharad.recepemgmt.service.RecepesMgmtControllerService;

/**
 * This is the implementaion class of interface RecepesMgmtControllerService
 * @author SHARAD
 *
 */
@Service
public class RecepesMgmtControllerServiceImpl implements RecepesMgmtControllerService {

	
	private RecepeRepository recepeRepository;
	
	@Autowired
	public RecepesMgmtControllerServiceImpl(RecepeRepository therecepeRepository) {
		recepeRepository = therecepeRepository;
	}
	/**
	 * findAll to find all recepes
	 * @author SHARAD
	 */
	@Override
	public List<Recepes> findAll() {

		return recepeRepository.findAll();
	}

	/**
	 * 	 * findById to find all recepes using recepe Id
	 * @author SHARAD
	 */
	@Override
	public Recepes findById(int recepeId) {
		// TODO Auto-generated method stub
		Optional<Recepes> result = recepeRepository.findById(recepeId);

		Recepes theRecepes = null;

		if (result.isPresent()) {
			theRecepes = result.get();
		}
		else {
			// we didn't find the employee
			throw new RuntimeException("Did not find theRecepes id - " + recepeId);
		}
		return theRecepes;
	}

	/**
	 * save used to create/update new recepe
	 * @author SHARAD
	 */
	@Override
	public void save(Recepes therecepe) {
		recepeRepository.save(therecepe);
	}

	/**
	 * deleteById is  used to delete record using Id
	 * @author SHARAD
	 */
	@Override
	public void deleteById(int theId) {
		recepeRepository.deleteById(theId);
		
	}
	
}