package com.sharad.recepemgmt.bean;

import java.util.Arrays;

/**
 * This Class will collect list of recepes and each recepes ingredient list
 * @author SHARAD
 *
 */

public class RecepesList {
	
	private Recepes[] recepies;

	public Recepes[] getRecepies() {
		return recepies;
	}

	public void setRecepies(Recepes[] recepies) {
		this.recepies = recepies;
	}

	public RecepesList() {
	}

	public RecepesList(Recepes[] recepies) {
		this.recepies = recepies;
	}

	@Override
	public String toString() {
		return "RecepiesList [recepies=" + Arrays.toString(recepies) + "]";
	}

}
