package com.sharad.recepemgmt.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * This is the bean(Entity) class for Table RECEPE_INGREDENTS
 * @author SHARAD
 *
 */

@Entity
@Table(name="RECEPE_INGREDENTS")
public class Ingredients {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="INGREDENTS_ID")
	private int ingredentsId;
	
	@Column(name="INGREDENTS")
	private String ingredents;
	
	/*
	 * @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE,
	 * CascadeType.DETACH, CascadeType.REFRESH})
	 */
	@ManyToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name="RECEPE_ID")
	@JsonBackReference
	private Recepes recepes;
	
	
	public Ingredients() {
		
	}


	public String getIngredents() {
		return ingredents;
	}


	public void setIngredents(String ingredents) {
		this.ingredents = ingredents;
	}


	public Recepes getRecepes() {
		return recepes;
	}


	public void setRecepes(Recepes recepes) {
		this.recepes = recepes;
	}


	public Ingredients(String ingredents) {
		this.ingredents = ingredents;
	}


	public int getIngredentsId() {
		return ingredentsId;
	}


	public void setIngredentsId(int ingredentsId) {
		this.ingredentsId = ingredentsId;
	}
	
		public Ingredients(int ingredentsId, String ingredents, Recepes recepes) {
		this.ingredentsId = ingredentsId;
		this.ingredents = ingredents;
		this.recepes = recepes;
	}


	@Override
	public String toString() {
		return "Ingredients [ingredentsId=" + ingredentsId + ", ingredents=" + ingredents + "]";
	}
}
