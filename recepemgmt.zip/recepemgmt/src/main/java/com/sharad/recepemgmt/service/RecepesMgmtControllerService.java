package com.sharad.recepemgmt.service;

import java.util.List;

import com.sharad.recepemgmt.bean.Recepes;

/**
 * This is the interface used to define all the operations
 * @author SHARAD
 *
 */
public interface RecepesMgmtControllerService {
	
	List<Recepes> findAll();
	Recepes findById(int theId);
	void save(Recepes therecepe);		
	void deleteById(int theId);
	
}
